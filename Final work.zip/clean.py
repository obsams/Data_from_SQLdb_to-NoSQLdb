# import the neccesaary python libraries
import pandas as pd
import numpy as np

file_path = "D:/UWE/Data fundamentals/Assignment2/crop.csv"
cropped_df = pd.read_csv(file_path, sep = ";")

# create a list of the sites IDs and their matching locations 
SAMM=[
[188,'AURN Bristol Centre'], [203,'Brislington Depot'], [206,'Rupert Street'], [209,'IKEA M32'],
[213,'Old Market'],[215,'Parson Street School'], [228,'Temple Meads Station'], [270,'Wells Road'],
[271,'Trailer Portway P&R'], [375,'Newfoundland Road Police Station'], [395,"Shiner's Garage"], 
[452,'AURN St Pauls'], [447,'Bath Road'], [459,'Cheltenham Road \ Station Road'], [463,'Fishponds Road'],
[481,'CREATE Centre Roof'], [500,'Temple Way'], [501,'Colston Avenue']
]

# make it into a dictionary
sam_dict = dict(SAMM)
sam_dict

def isValid(row):
    try:
        if sam_dict[row.SiteID] == row.Location:
            return True
    except KeyError:    # checks when the SiteID is not present or not in the SiteID list given
        return False
    return False

# store all valid entries in a list
valids = []
mismatches = []
for i in cropped_df.itertuples():
    if isValid(i):
        valids.append(i)
    else:
        print(f"line number ==> {i.Index:10}, mismatch ==> {i.SiteID:5}, {i.Location}")

# make a clean dataframe from the valid entries list
clean_df = pd.DataFrame(valids).drop(columns=["Index"])
clean_df.columns = cropped_df.columns

# save the dataframe to a csv file
clean_df.to_csv("D:/UWE/Data fundamentals/Assignment2/clean.csv", index= False, sep = ";")
