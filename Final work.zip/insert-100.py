# importing libraries and dependencies
import pandas as pd
import numpy as np
import mysql.connector
from sqlalchemy import create_engine

# Load in the clean.csv file as a dataframe df
df = pd.read_csv("D:/UWE/Data fundamentals/Assignment2/clean.csv", delimiter=';')

# create a dataframe  that holds the first 100 records out of the df dataframe
try:
    insert_100_df = df[:100]
except Exception:
    insert_100_df = df
insert_100_df

# connection credentials and strings to MySQL
sqlEngine       = create_engine("mysql+pymysql://root:@127.0.0.1", echo=True)

dbConnection    = sqlEngine.connect()

#  create database if it does not already exists
try:
    dbConnection.execute("CREATE DATABASE IF NOT EXISTS pollutiondb2;")

except mysql.connector.Error as err:
    print(err)
    print("Failed to create database")

try:
    dbConnection.execute("Use pollutiondb2;")

except mysql.connector.Error as err:
    print(err)
    print("Database does not exist")

tableName = 'bristol_air_quality_data_cleaned_100_inserts'

try:
    frame = insert_100_df.to_sql(tableName, con=dbConnection, if_exists='replace', index = False, chunksize = 1000) # import csv into database db2

except ValueError as vx:

    print('ValueError:',vx)

except Exception as ex:   

    print('Exception:',ex)

else:

    print("Table %s populated successfully."% tableName);  # print out statement if the db2 database was successfully populated for the first 100 inserts 

finally: 
    dbConnection.close()# close database connection