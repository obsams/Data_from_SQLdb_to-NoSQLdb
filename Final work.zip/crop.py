import pandas as pd
import numpy as np
import datetime

path1 = "bristol-air-quality-data.csv"
path2 = 'D:/UWE/Data fundamentals/Assignment2/bristol-air-quality-data.csv'
bristol_air_data=pd.read_csv(path2, sep =";") 

# converting the series Data Time to a pandas datatype object
bristol_air_data['Date Time'] = pd.to_datetime(bristol_air_data['Date Time'])

# Crop the file to delete any records before 00:00 1 Jan 2010 (1262304000)
cut_off_duration ="2010-01-01T00:00:00+00:00"
bristol_air_dat =bristol_air_data['Date Time'] >=cut_off_duration
bristol_air_data=bristol_air_data.loc[bristol_air_dat]

# to check if no null values exist and display the results
bristol_air_data2_crop_df=bristol_air_data[bristol_air_data['SiteID'].isnull()]

# save the dataframe to a csv file
bristol_air_data.to_csv("D:/UWE/Data fundamentals/Assignment2/crop.csv", index= False, sep = ";")