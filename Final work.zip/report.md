# Refective Report for Tasks 1-4 of Course Assignment-Data Management Fundamentals
## Course-UFCFLR-15,21JAN/1
## Student ID-21051947

### Introduction
We had a period from 15 February 2022 to 12 May 2022 to model, cleanse, normalize, map, query and analyse real-world world data of observations of Bristol air quality data which spans from the duration of the period of 2004 to February 2022 for eighteen monitoring stations.
### Challenges
Some of the challenges it has easy as we had to learn and be accustomed to modern technologies and techniques over the study of the course relating to Database Management over a brief period.But after reasearch using the numpy,pandas,seaborn,Matplotlib documnetation I was able to accomplish it.
### Procedure and Steps 
A lot of the task has a lot of options to implement but a few served right for me as it was easy to understand, easy to implement and free of errors like using the pandas' method to import and export my CSV file to a data frame and vice versa. With importing data into python, the csv.reader and it variations could be used to  read in a CSV file as well .The DateTime series had to be converted into a pandas datatype object so it can be worked upon (‘User Guide — pandas 1.4.2 documentation’, 2022) through other methods like using the built-in feature of python to do the same. (‘CSV — CSV File Reading and Writing — Python 3.10.4 documentation, 2022) in task 1a.
In task 1b, a lot of options were available in cropping the data frame in pandas/NumPy as per the question like creating a data frame out of the list of sites ID and site locations instead of a dictionary for comparison to remove the dud records to generate clean.csv and  the use of several indexing options named series ways like .loc[], .iloc[ ], .ix[ ], .isnull(), etc (‘Indexing and selecting data — pandas 1.4.2 documentation’, 2013)
(‘Copies and views — NumPy v1.22 Manual’, 2022). Using a function and itertuples () method is a function, I compared the dictionary of site IDs and their matching locations to index, filter, store and create a clean CSV file (‘Indexing and selecting data — pandas 1.4.2 documentation’, 2013b), (‘pandas.DataFrame.itertuples — pandas 1.4.2 documentation’, 2022)
Using sqlAlchemy help to work with querying and creating databases in task 3 since I am not so used to SQL syntax, also as it is fastest than the other options when working with databases with python and doing the first 100 imports into the database as well as create take the cleaned CSV as input, create a new database instance-pollution-db2 and populate it(‘MySQL and MariaDB — SQLAlchemy 1.4 Documentation’, 2022).
Using basic SQL syntax like WHERE, ORDER BY, FROM, MAX, GROUP BY, and HAVING in lower case, I was able to get outputs as requested in the SQL statements in task 4. (‘SQL Tutorial’, 2022).

### Suggestive Visualisations to use
In visualising the data, python seaborn will be especially useful to get clean and clear visualizations. Using a scatter plot, histograms, heat maps plots of the pollution levels on the y-axes against the datatime for each site on the x-axes, could show pollution levels with the pollutants were great, low, and minimal to inform decision making (‘User guide and tutorial — seaborn 0.11.2 documentation,’ 2012), (‘Matplotlib documentation — Matplotlib 3.5.2 documentation’, 2012).
### Learning Outcomes
In the end, some of the learning outcomes include it has paid off as a positive experience as such an assignment has covered the very basics of handling data in the SQL which is the basics and a motivation to learn and explore more in this field and serve as the basics of further studies about databases like when studying Big data.
The assignment has exposed me to the sort of data sizes ‘big data in the real world we will be working with. This of course made me aware of the limitations of laptops and other personal computers in processing big data. It has also been a revelation to the sort of data formats to expect in the workplace- CSV, data frame, etc and the sort of analysis to be performed on data to as make it ready for analysing, these include cleaning and being aware of missing or null values.
### Conclusion
Next time I will make more full use of resources available online and references brought to our attention during the coursework and get accustomed to them as soon as possible so it becomes first-hand.
### References
‘Copies and views — NumPy v1.22 Manual’ (2022) Numpy.org.2022 [online]. Available from: https://numpy.org/doc/stable/user/basics.copies.html?highlight=indexing [Accessed 8 May 2022].
‘csv — CSV File Reading and Writing — Python 3.10.4 documentation’ (2022) Python.org.2022 [online]. Available from: https://docs.python.org/3/library/csv.html?highlight=csv [Accessed 8 May 2022].
‘Indexing and selecting data — pandas 1.4.2 documentation’ (2013a) Pydata.org.2013 [online]. Available from: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html?highlight=indexing [Accessed 8 May 2022].
‘Indexing and selecting data — pandas 1.4.2 documentation’ (2013b) Pydata.org.2013 [online]. Available from: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html [Accessed 15 May 2022].
‘Matplotlib documentation — Matplotlib 3.5.2 documentation’ (2012) Matplotlib.org.2012 [online]. Available from: https://matplotlib.org/stable/index.html [Accessed 15 May 2022].
‘MySQL and MariaDB — SQLAlchemy 1.4 Documentation’ (2022) Sqlalchemy.org.2022 [online]. Available from: https://docs.sqlalchemy.org/en/14/dialects/mysql.html [Accessed 8 May 2022].
‘pandas.DataFrame.itertuples — pandas 1.4.2 documentation’ (2022) Pydata.org.2022 [online]. Available from: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.itertuples.html [Accessed 15 May 2022].
‘SQL Tutorial’ (2022) W3schools.com.2022 [online]. Available from: https://www.w3schools.com/sql/ [Accessed 15 May 2022].
‘User Guide — pandas 1.4.2 documentation’ (2022) Pydata.org.2022 [online]. Available from: https://pandas.pydata.org/pandas-docs/stable/user_guide/index.html [Accessed 8 May 2022].
‘User guide and tutorial — seaborn 0.11.2 documentation’ (2012) Pydata.org.2012 [online]. Available from: https://seaborn.pydata.org/tutorial.html# [Accessed 8 May 2022].




