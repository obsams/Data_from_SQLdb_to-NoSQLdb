# Reflective Report for Tasks 5 of Course Assignment-Data Management Fundamentals
## Course-UFCFLR-15,21JAN/1
## Student ID-21051947

### Introduction

We had a period from 15 February 2022 to 12 May 2022 to model, implement and query for a given monitor(station) which is part of the real-world world data of observations of Bristol air quality data which spans from the duration of the period of 2004 to February 2022 for 18 monitoring stations using a NoSQL database using Cheltenham Road/Station Road as a case study 
Some of the challenges where I was not so used too much to NoSQL technologies and techniques before this course and we studied it for only a brief period during the Database Management lectures. 
Some parts of the NoSQL tasks were difficult to comprehend, but I did my best with good research from NoSQL documentation and Mongo DB documentation it was smoothly done.

### Modelling and implementation Details

For successful importation of data into MongoDB, the following needs to install
pyMongo, a driver to interact between python and MongoDB (‘PyMongo 4.1.1 Documentation — PyMongo 4.1.1 documentation’, 2022)
MongoDB Compass, a MongoDB GUI for analysing and handling data in MongoDB (‘MongoDB Compass’, 2022)
Since the clean.csv data contained more than one join, a scripting language had to come in with Python was the ideal choice with the help of the pyMongo driver which had to be installed on my computer using the command pip install pyMongo. Afterwards, the connection to MongoDB Compass using the connection strings to connect to MongoDB compass (Mongoclient) was established. The clean.csv was then used to create and populate a MongoDB database to create tables and collections. With the MongoDB now populated, the Cheltenham Road/Station Road records were queried it had to be formatted in a scripting language-python was extremely helpful to extract the data, transform it, and write the results saved to a JSON (JavaScript Object Notation) file, format which is best suited in MongoDB. (‘MySQL To MongoDB Migration Guide | MongoDB’, 2022)
In the end, some of the learning outcomes include: It includes, I now have the basics of handling data(JSON format) in  NoSQL using MongoDB, I have also seen the  limitations of MongoDB and the need to learn more about NoSQL data management software like Redis,neo4j*best to capture relationships better, etc in addition as much of the big data in the real world is in NoSQL format.
### The code to populate the Nosql DB-MOngoBD
``` importing libaries
import pandas as pd
import numpy as np
import pymongo
from pymongo import MongoClient

# reading in the clean csv as a datafram df
df = pd.read_csv("D:UWE/Data fundamentals/Assignment2/clean.csv", delimiter=';')
df.head(50)

# Making a Connection with MongoClient
client = MongoClient("mongodb://localhost:27017/")

# database
db = client["bristol_air_database"]

print(client.list_database_names())

# modeling data for Cheltenham Road \ Station Road
data = df[df['SiteID'] == 459]

# Get station name
station_name = data['Location'].unique()[0]

# reseting the index
data.reset_index(inplace=True)
data = data.drop(['index'], axis=1)

# convert dataframe into dict or json format
data_dict = data.to_dict("records")

# collection
station= db[station_name]

# Cheltenham Road \ Station Road data successfully inserted 
station.insert_many(data_dict)
data
```
### Conclusion
Next time I will make more full use of resources available online and references brought to our attention during the coursework and get accustomed to them as soon as possible so it becomes hands-on.

### References
‘MongoDB Compass’ (2022) MongoDB.2022 [online]. Available from: https://www.mongodb.com/products/compass [Accessed 15 May 2022].
‘MySQL To MongoDB Migration Guide | MongoDB’ (2022) MongoDB.2022 [online]. Available from: https://www.mongodb.com/basics/mysql-to-mongodb [Accessed 10 May 2022].
‘PyMongo’ (2022) Mongodb.com.2022 [online]. Available from: https://www.mongodb.com/docs/drivers/pymongo/ [Accessed 10 May 2022].
‘PyMongo 4.1.1 Documentation — PyMongo 4.1.1 documentation’ (2022) Readthedocs.io.2022 [online]. Available from: https://pymongo.readthedocs.io/en/stable/#about-this-documentation [Accessed 15 May 2022].





