# Return the mean values of PM2.5 (particulate matter <2.5 micron diameter) & VPM2.5 (volatile particulate 
# matter <2.5 micron diameter) by each station for the year 2019 for readings taken on or near 08:00 hours 
# (peak traffic intensity).

Select Date_Time, SiteID , avg(PM2_5), avg(VPM2_5)
From bristol_air_quality_data
group by year(Date_Time), hour(Date_Time), SiteID
having year(Date_Time) = 2019 and hour(Date_Time) = 8
order by year(Date_Time), SiteID