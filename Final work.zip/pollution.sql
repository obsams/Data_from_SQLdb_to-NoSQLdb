-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema pollution-er
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema pollution-er
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `pollution-er` DEFAULT CHARACTER SET utf8 ;
USE `pollution-er` ;

-- -----------------------------------------------------
-- Table `pollution-er`.`Site`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pollution-er`.`Site` (
  `Site_ID` INT NOT NULL,
  `Location` VARCHAR(45) NOT NULL,
  `Geopint` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Site_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pollution-er`.`Readings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pollution-er`.`Readings` (
  `Readings_ID` INT NOT NULL AUTO_INCREMENT,
  `NOx` FLOAT NOT NULL,
  `Date_Time` DATETIME NOT NULL,
  `NO2` FLOAT NOT NULL,
  `NO` FLOAT NOT NULL,
  `Site_ID` FLOAT NOT NULL,
  `PM10` FLOAT NOT NULL,
  `NVPM10` FLOAT NOT NULL,
  `VPM10` FLOAT NOT NULL,
  `NVPM2.5` FLOAT NOT NULL,
  `PM2.5` FLOAT NOT NULL,
  `VPM2.5` FLOAT NOT NULL,
  `CO` FLOAT NOT NULL,
  `O3` FLOAT NOT NULL,
  `SO2` FLOAT NOT NULL,
  `Temperature` FLOAT NOT NULL,
  `RH` FLOAT NOT NULL,
  `Air_Pressure` FLOAT NOT NULL,
  `Location` FLOAT NOT NULL,
  `geo_point_2d` FLOAT NOT NULL,
  `Date_Start` DATETIME NOT NULL,
  `Date_End` FLOAT NOT NULL,
  `Current` VARCHAR(45) NOT NULL,
  `Instrument Type` VARCHAR(45) NOT NULL,
  `Site_Site_ID` INT NOT NULL,
  PRIMARY KEY (`Readings_ID`, `Site_Site_ID`),
  INDEX `fk_Readings_Site_idx` (`Site_Site_ID` ASC),
  CONSTRAINT `fk_Readings_Site`
    FOREIGN KEY (`Site_Site_ID`)
    REFERENCES `pollution-er`.`Site` (`Site_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pollution-er`.`Schema`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pollution-er`.`Schema` (
  `measure` VARCHAR(50) NOT NULL,
  `Desc` VARCHAR(150) NOT NULL,
  `Unit` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`measure`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
