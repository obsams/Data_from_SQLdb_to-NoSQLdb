import pandas as pd
import mysql.connector
from sqlalchemy import create_engine

df = pd.read_csv("clean.csv", delimiter=';')
# rename columns to replace dots and spaces with underscore
df.columns = [i.replace(" ", "_").replace(".", "_") for i in df.columns]

# replace all numeric values by their absolute values
cols = df.select_dtypes(exclude="object").columns
df[cols] = abs(df[cols])

# fill nan values with zero
df = df.fillna(0)

# convert the date column to datetime
df.Date_Time = pd.to_datetime(df.Date_Time)

# write to the database
sqlEngine = create_engine("mysql+pymysql://root:@127.0.0.1", echo=True)

dbConnection = sqlEngine.connect()


try:
    dbConnection.execute("CREATE DATABASE IF NOT EXISTS pollutiondb2;")

except mysql.connector.Error as err:
    print(err)
    print("Failed to create database")

try:
    dbConnection.execute("Use pollutiondb2;")

except mysql.connector.Error as err:
    print(err)
    print("Database does not exist")

tableName = 'bristol_air_quality_data'

try:
    frame = df.to_sql(tableName, con=dbConnection, if_exists='replace', index = False, chunksize = 10000)

except ValueError as vx:

    print('ValueError:',vx)

except Exception as ex:   

    print('Exception:',ex)

else:

    print("Table %s populated successfully."% tableName);   

finally:

    dbConnection.close()
