# Return the date/time, station name and the highest recorded value of nitrogen oxide (NOx) found in the 
# dataset for the year 2019.

select Date_Time, SiteID, max(NOx)
from bristol_air_quality_data
group by year(Date_Time)
having year(Date_Time) = 2019