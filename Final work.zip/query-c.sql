# Extend the previous query to show these values for all stations in the years 2010 to 2019.

Select Date_Time, SiteID , avg(PM2_5), avg(VPM2_5)
From bristol_air_quality_data
group by year(Date_Time), hour(Date_Time), SiteID
having year(Date_Time) >= 2010 and year(Date_Time) <= 2019 and hour(Date_Time) = 8
order by year(Date_Time), SiteID